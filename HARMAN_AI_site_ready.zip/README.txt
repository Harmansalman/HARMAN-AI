HARMAN AI - website prototype
1. Upload this ZIP using a static hosting provider's "Drop a folder, or a zip" / direct upload option.
2. The homepage file is index.html.
3. This is a front-end prototype. Live AI chat, image generation, secure admin login, voice, payments, and actual location sharing are not connected. Do not use the demo admin form for real credentials.
